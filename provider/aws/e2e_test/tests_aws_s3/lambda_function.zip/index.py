def handler(event, context):
    """Process S3 events"""
    print("S3 event received:", event)
    
    # Extract bucket and object information
    for record in event.get('Records', []):
        bucket = record['s3']['bucket']['name']
        key = record['s3']['object']['key']
        event_name = record['eventName']
        print(f"Event: {event_name}, Bucket: {bucket}, Key: {key}")
    
    return {
        'statusCode': 200,
        'body': 'S3 event processed successfully'
    }
